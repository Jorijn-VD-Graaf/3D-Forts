﻿using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Client : MonoBehaviour
{
    /// <summary>Size in bytes of the data buffer</summary>
    public static int dataBufferSize = 4096;

    public InputField ipInput;

    private string ip;
    private int port = 42069;
    public int myId = 0;
    public TCP tcp;

    private delegate void PacketHandler(Packet packet);
    private static Dictionary<int, PacketHandler> packetHandlers;

    #region Startup
    /// <summary>
    /// Starts client and attemps to connect to server
    /// </summary>
    public void StartClient()
    {
        tcp = new TCP();
        ip = ipInput.text;
        print("connecting to server");
        InitializeClientData();
        tcp.Connect(ip, port);
    }
    /// <summary>Sets up packet handlers</summary>
    private void InitializeClientData()
    {
        packetHandlers = new Dictionary<int, PacketHandler>()
        {
            { (int) ServerPackets.welcome, WelcomeReceived}
        };
        print("Initzailzed packet handlers.");
    }
    #endregion

    #region Packet handlers
    /// <summary>
    /// Handles welcome packet and responds with ID
    /// </summary>
    /// <param name="packet">Recieved packet</param>
    public void WelcomeReceived(Packet packet)
    {
        string msg = packet.ReadString();
        myId = packet.ReadInt();

        print($"Message from server: {msg}");
        using (Packet _packet = new Packet((int)ClientPackets.welcomeReceived))
        {
            _packet.Write(myId);
            tcp.SendData(_packet);
        }
    }
    #endregion
    public class TCP
    {
        public TcpClient socket;

        private NetworkStream stream;
        private Packet receivedData;
        private byte[] receiveBuffer;

        /// <summary>
        /// Attempts to connect to server
        /// </summary>
        /// <param name="ip">Server ip</param>
        /// <param name="port">Server port</param>
        public void Connect(string ip, int port)
        {
            socket = new TcpClient
            {
                ReceiveBufferSize = dataBufferSize,
                SendBufferSize = dataBufferSize
            };

            receiveBuffer = new byte[dataBufferSize];
            try
            {
                socket.BeginConnect(IPAddress.Parse(ip), port, ConnectCallBack, socket);
            }
            catch (SocketException e)
            {
                Debug.LogError(e);
            }
        }

        /// <summary>
        /// Runs when connection sucsesfull or time out
        /// </summary>
        /// <param name="result">result of the connection attempt</param>
        private void ConnectCallBack(IAsyncResult result)
        {
            socket.EndConnect(result);
            if (!socket.Connected)
            {
                return;
            }
            print($"connected to {socket.Client.RemoteEndPoint}");
            stream = socket.GetStream();

            receivedData = new Packet();

            stream.BeginRead(receiveBuffer, 0, dataBufferSize, ReceiveCallback, null);
        }
        
        /// <summary>
        /// sends data to server
        /// </summary>
        /// <param name="packet">packet to send</param>
        public void SendData(Packet packet)
        {
            packet.WriteLength();
            try
            {
                if (socket != null)
                {
                    stream.BeginWrite(packet.ToArray(), 0, packet.Length(), null, null);
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"Error while sending TCP data: {e}");
            }
        }

        /// <summary>
        /// gets called when data is received
        /// </summary>
        private void ReceiveCallback(IAsyncResult result)
        {
            try
            {
                int byteLenght = stream.EndRead(result);
                if (byteLenght <= 0)
                {
                    //corrupted packet
                    return;
                }
                byte[] data = new byte[byteLenght];
                Array.Copy(receiveBuffer, data, byteLenght);

                receivedData.Reset(HandleData(data));
                stream.BeginRead(receiveBuffer, 0, dataBufferSize, ReceiveCallback, null);
            }
            catch
            {

            }
        }
        /// <summary>
        /// Reads packet and sends too appropaite packet handler
        /// </summary>
        /// <param name="data">the packet in a byte array</param>
        /// <returns></returns>
        private bool HandleData(byte[] data)
        {
            int packetLength = 0;

            receivedData.SetBytes(data);

            //first 4 bytes are packet size
            if (receivedData.UnreadLength() >= 4)
            {
                packetLength = receivedData.ReadInt();
                if (packetLength <= 0)
                {
                    return true;
                }
            }
            while (packetLength > 0 && packetLength <= receivedData.UnreadLength())
            {
                byte[] packetBytes = receivedData.ReadBytes(packetLength);
                using (Packet packet = new Packet(packetBytes))
                {
                    //reads packet type and runs approipete handler
                    int packetId = packet.ReadInt();
                    packetHandlers[packetId](packet);
                }

                packetLength = 0;
                if (receivedData.UnreadLength() >= 4)
                {
                    //not the entire packet has been recieved yet
                    packetLength = receivedData.ReadInt();
                    if (packetLength <= 0)
                    {
                        return true;
                    }
                }
            }
            if (packetLength <= 1)
            {
                //corrupted packet
                return true;
            }

            return false;
        }
    }
}

